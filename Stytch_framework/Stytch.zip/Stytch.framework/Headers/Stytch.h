//
//  Stytch.h
//  Stytch
//
//  Created by Edgar Kroman on 2020-12-04.
//

#import <Foundation/Foundation.h>

//! Project version number for Stytch.
FOUNDATION_EXPORT double StytchVersionNumber;

//! Project version string for Stytch.
FOUNDATION_EXPORT const unsigned char StytchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Stytch/PublicHeader.h>


